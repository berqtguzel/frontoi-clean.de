<?php
    $inertiaLocale = $page['props']['locale'] ?? ($page['props']['global']['locale'] ?? null);
    $htmlLocale = $inertiaLocale ?: app()->getLocale();
?>
<!DOCTYPE html>
<html lang="<?php echo e($htmlLocale); ?>"
      data-locale="<?php echo e($htmlLocale); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    
    <link rel="dns-prefetch" href="https://omerdogan.de">
    <link rel="preconnect" href="https://omerdogan.de" crossorigin>
    <link rel="dns-prefetch" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    
    <?php if(isset($meta['ogImage']) && $meta['ogImage']): ?>
        <link rel="preload" as="image" href="<?php echo e($finalOgImage); ?>" fetchpriority="high" type="image/webp">
    <?php endif; ?>



    
    <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/app.css',
        'resources/js/app.jsx',
    ]); ?>

    <?php
        use Illuminate\Support\Str;

        $props = $page['props'] ?? [];
        $global = $props['global'] ?? [];
        $locale = $props['locale'] ?? ($global['locale'] ?? app()->getLocale());
        $settings = $global['settings'] ?? [];
        $general = $settings['general'] ?? [];
        $seo = $settings['seo'] ?? [];

        $siteName = $general['site_name'] ?? config('app.name');

        $currentUrl = url()->current();

        $meta = [
            'title' => $seo['meta_title'] ?? $siteName,
            'description' => $seo['meta_description'] ?? '',
            'keywords' => $seo['meta_keywords'] ?? '',
            'canonicalUrl' => $currentUrl,
            'ogImage' => $seo['og_image'] ?? asset('og-default.jpg'),
        ];

        $finalTitle = Str::limit(strip_tags($meta['title']), 60);
        $finalDesc = Str::limit(strip_tags($meta['description']), 160);
        $finalKeywords = $meta['keywords'] ?? '';
        $canonicalUrl = $meta['canonicalUrl'] ?? $currentUrl;
        $finalOgImage = $meta['ogImage'] ?? asset('og-default.jpg');

        // Çoklu dil ayarları
        $languages = $global['languages'] ?? [
            ['code' => 'de'],
            ['code' => 'en'],
            ['code' => 'tr'],
        ];

        $slug = $props['slug'] ?? request()->path();
        if (Str::startsWith($slug, "$locale/")) {
            $slug = substr($slug, strlen("$locale/"));
        }
    ?>

    
    <title inertia><?php echo e($finalTitle); ?></title>
    <meta name="description" content="<?php echo e($finalDesc); ?>" inertia>

    <?php if($finalKeywords): ?>
        <meta name="keywords" content="<?php echo e($finalKeywords); ?>" inertia>
    <?php endif; ?>

    <link rel="canonical" href="<?php echo e($canonicalUrl); ?>" inertia>

    <meta property="og:type" content="website" inertia>
    <meta property="og:site_name" content="<?php echo e($siteName); ?>" inertia>
    <meta property="og:title" content="<?php echo e($finalTitle); ?>" inertia>
    <meta property="og:description" content="<?php echo e($finalDesc); ?>" inertia>
    <meta property="og:url" content="<?php echo e($canonicalUrl); ?>" inertia>
    <meta property="og:image" content="<?php echo e($finalOgImage); ?>" inertia>

    <meta name="twitter:card" content="summary_large_image" inertia>

    
    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <link rel="alternate"
              hreflang="<?php echo e($lang['code']); ?>"
              href="<?php echo e(url($lang['code'].'/'.$slug)); ?>" />
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <link rel="alternate" hreflang="x-default" href="<?php echo e($canonicalUrl); ?>" />

    <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
</head>

<body class="font-sans antialiased bg-white">
    <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
</body>
</html>
<?php /**PATH D:\laragon\www\oiclean\front\resources\views/app.blade.php ENDPATH**/ ?>